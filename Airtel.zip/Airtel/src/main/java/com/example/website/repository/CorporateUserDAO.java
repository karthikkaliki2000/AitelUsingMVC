package com.example.website.repository;

import java.util.Optional;

import com.example.website.domain.CorporateUser;

public class CorporateUserDAO implements DAO<CorporateUser> {

	@Override
	public Optional<CorporateUser> get(Integer id) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public int save(CorporateUser t) {
		// TODO Auto-generated method stub
		return 0;
	}

}
