package com.example.website.web;

import com.example.website.domain.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.website.service.UserService;


@Controller
public class SignUpController {

	@Autowired
	UserService normalUserService;
	@Autowired
	UserService corporateUserService;
	
	
	UserService userService;
	
	
	public void SignUpController() {
		
	}
	
	
	
	@RequestMapping("/registerUser")
	public String userinfo(@ModelAttribute(value = "user") NormalUser user, ModelMap	model) {
		NormalUser normalUser=new NormalUser();
		CorporateUser corporateUser=new CorporateUser();
//		if(user.getUservalue().equals("normal")) {
//			userService=normalUserService;
//		}
//		else {
//			userService=corporateUserService;
//		}
		userService = corporateUserService;
		
		if(userService.getUser().equals("normal")) {
			model.addAttribute("user", normalUser);
			System.out.println("returning normal ");
			return "normalsignup";
		}
		
		model.addAttribute("user", corporateUser);
		System.out.println("returning corporate ");
		return "corporatesignup";
	}
	

	@RequestMapping("/normalplans")
	public String getSignUpPagenormalUser(@ModelAttribute(value="normalUser") NormalUser user,ModelMap map) {
		NormalPlan	normalPlan=new NormalPlan();
		map.addAttribute("normalPlan", normalPlan);
		return "normalplans";
	}
	
	@RequestMapping("/corporateplans")
	public String getSignUpPagecorporateUser(@ModelAttribute(value="user") CorporatePlan user,ModelMap map) {
		CorporatePlan corporatePlan=new CorporatePlan();
		map.addAttribute("corporatePlan", corporatePlan);
		return "corporateplans";
	}
	
	@RequestMapping("/thankyou")
	public String thankyou() {
		return "thankyou";
	}
	
	
	
	
}
