package com.example.website.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.website.domain.User;

@Service
public class CorporateUserService implements UserService {

	
	@Autowired
	User corporateUser;
	@Override
	public String getUser() {
		return corporateUser.getUserValue();
	}

	@Override
	public boolean signUp(String name, String gender, String location, int age, long phoneNo) {
		// TODO Auto-generated method stub
		return false;
	}

}
