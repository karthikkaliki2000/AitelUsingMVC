package com.example.website.repository;

import java.util.Optional;

import com.example.website.domain.CorporatePlan;

public class CorporatePlanDAO implements DAO<CorporatePlan> {

	@Override
	public Optional<CorporatePlan> get(Integer id) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public int save(CorporatePlan t) {
		// TODO Auto-generated method stub
		return 0;
	}

}
