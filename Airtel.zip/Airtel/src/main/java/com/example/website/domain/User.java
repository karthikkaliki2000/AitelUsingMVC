package com.example.website.domain;

public interface User {
	
	public String getUserValue();
	public String getUserName();
	public String getRegisteredNumber();
	public String getPlanType();
	
}
