package com.example.website.repository;

import java.util.Optional;

import com.example.website.domain.NormalUser;

public class NormalUserDAO implements DAO<NormalUser> {

	@Override
	public Optional<NormalUser> get(Integer id) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public int save(NormalUser t) {
		// TODO Auto-generated method stub
		return 0;
	}

}
