package com.example.website.repository;

import java.util.Optional;

import com.example.website.domain.NormalPlan;

public class NormalPlanDAO implements DAO<NormalPlan> {

	@Override
	public Optional<NormalPlan> get(Integer id) {
		// TODO Auto-generated method stub
		return Optional.empty();
	}

	@Override
	public int save(NormalPlan t) {
		// TODO Auto-generated method stub
		return 0;
	}

}
