package com.example.website.domain;

import org.springframework.stereotype.Component;

@Component
public class CorporateUser implements User{
	String userType;
	String registeredNumber;
	String name;
	String planType;
	public CorporateUser(){
	}
//	generate getters and setters
	public String getRegisteredNumber() {
		return registeredNumber;
	}
	public void setRegisteredNumber(String registeredNumber) {
		this.registeredNumber = registeredNumber;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPlanType() {
		return planType;
	}
	public void setPlanType(String planType) {
		this.planType = planType;
	}

	public void setUserType(String userType) {
		this.userType = userType;
	}
	public String getUserType() {
		return userType;
	}

	@Override
	public String getUserValue() {
		return "corporate";
	}

	@Override
	public String getUserName() {
		// TODO Auto-generated method stub
		return name;
	}
}
