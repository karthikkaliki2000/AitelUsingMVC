package com.example.website.domain;

public interface Plan {

}
