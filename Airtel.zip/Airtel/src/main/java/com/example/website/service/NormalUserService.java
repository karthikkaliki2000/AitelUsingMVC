package com.example.website.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.website.domain.User;

@Service
public class NormalUserService implements UserService {
	
	@Autowired
	User normalUser;
	@Override
	public String getUser() {
		// TODO Auto-generated method stub
		return normalUser.getUserValue();
	}

	@Override
	public boolean signUp(String name, String gender, String location, int age, long phoneNo) {
		// TODO Auto-generated method stub
		
		return false;
	}

}
