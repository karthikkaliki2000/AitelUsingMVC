package com.example.website.domain;

import org.springframework.stereotype.Component;

@Component
public class NormalPlan implements Plan {
	String data;
	String calls;
	String duration;
	String speed;
//	generate getter and setters
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public String getCalls() {
		return calls;
	}
	public void setCalls(String calls) {
		this.calls = calls;
	}
	public String getDuration() {
		return duration;
	}
	public void setDuration(String duration) {
		this.duration = duration;
	}
	public String getSpeed() {
		return speed;
	}
	public void setSpeed(String speed) {
		this.speed = speed;
	}

}
