package com.example.website.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.example.website.domain.NormalUser;
import com.example.website.domain.User;
import com.example.website.service.UserService;

@Controller
public class HomeController {
	@Autowired
	@Qualifier("normalUserService")
	UserService userService;

	@RequestMapping(value="/home")
	public String getHomePage(ModelMap uiModel) {
//		BINDING THE MODEL ATTRIBUTE TO THE FORM
		User normalUser=new NormalUser();

		uiModel.addAttribute("user",normalUser);
		return "home";
	}
}
